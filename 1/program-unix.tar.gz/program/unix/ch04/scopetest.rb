$x = 0
 x = 0

require "sub.rb"

p $x  #=> 1
p x   #=> 0
