sum = 0
sum += 1
sum += 2
sum += 3
sum += 4
sum += 5
print "���: ",sum,"\n"
