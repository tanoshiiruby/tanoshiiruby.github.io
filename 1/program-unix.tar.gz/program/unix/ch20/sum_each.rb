sum = 0
(1..5).each{|i|
  sum += i
}
print "���v: ",sum,"\n"
