print("Hello, Ruby.\n")
