a = 20
if a >= 10 then
  print("bigger\n")
end
if a <= 9 then
  print("smaller\n")
end
