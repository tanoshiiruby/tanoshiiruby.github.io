puts "Hello,\n\tRuby."
p "Hello,\n\tRuby."
