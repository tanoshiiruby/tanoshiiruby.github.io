include Math
print("sin(3.1415) = ", sin(3.1415) ,"\n")
print("sqrt(10000) = ", sqrt(10000), "\n")
