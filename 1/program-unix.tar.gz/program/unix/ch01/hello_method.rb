def hello
  print("Hello, Ruby.\n")
end
hello()
