#!/usr/local/bin/ruby -Ks
# �u�����N�ɂ��ẴA���P�[�g�v�W�v�p���C�u����
#
# Copyright (C) 2001 TAKAHASHI 'Maki' Masayoshi  All right reserverd.
# This script is released under the same license as Ruby.
# See the Ruby license (http://www.ruby-lang.org/en/LICENSE.txt).

require 'nkf'

class EnqueteParser
  include NKF

  attr_accessor :checkbox

  def initialize(io)
    @io = io                        ## �Ǎ��pIO�I�u�W�F�N�g
    @enquetes = EnqueteList.new()   ## �񓚂̃��X�g
    @checkbox = Hash.new()          ## �`�F�b�N�{�b�N�X�p
    @enq_item = nil                 ## ���ݏ������̉�
    @prev_key = nil                 ## ���݂̐ݖ�
  end

  def parse()
    while line = @io.gets
      line = nkf('-sd', line)   ## Shift_JIS�����s�R�[�h��LF��
      if /^--- �������� ---\s*$/s =~ line
	enq_begin()
      elsif /^--- �����܂� ---\s*$/s =~ line
	enq_end()
      else
	enq_push(line)
      end
    end
    @enquetes
  end

  def enq_begin()
    @enq_item = @enquetes.make_new_item()
  end
  private :enq_begin

  def enq_push(line)
    if @enq_item
      if /^([A-Za-z0-9_-]*)\s=\s*(.*)/ =~ line
	## �ݖ�s
	key, value = $1, $2
	if @checkbox.keys.include?(key)
	  @enq_item[ key + "_" + value] = "YES"
	else
	  @enq_item[key] = value
	end
      else
	## �񓚂݂̂̍s
	if @enq_item[@prev_key]
	  key = @prev_key
	  @enq_item[@prev_key] << line
	end
      end
      @prev_key = key
    end
  end
  private :enq_push

  def enq_end()
    @enq_item = nil
  end
  private :enq_end

end

class Enquete < Hash

  def to_csv(keys=self.keys.sort)
    keys.collect{|key|
      '"'+self[key].to_s.gsub(/"/,'""')+'"'
    }.join(',')
  end

end

class EnqueteList < Array

  def make_new_item()
    item = Enquete.new()
    self.push(item)
    return item
  end

end

