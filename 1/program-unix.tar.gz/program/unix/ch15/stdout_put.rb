$stdout.puts "foo", "bar", "baz"
