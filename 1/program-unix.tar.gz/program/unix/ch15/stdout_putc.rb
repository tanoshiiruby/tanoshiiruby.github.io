$stdout.putc(82)
$stdout.putc(?R)
$stdout.putc("\n")
