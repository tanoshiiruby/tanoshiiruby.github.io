num0 = ARGV[0].to_i
num1 = ARGV[1].to_i

print num0, " + ", num1, " = ", num0 + num1, "\n"
print num0, " - ", num1, " = ", num0 - num1, "\n"
print num0, " * ", num1, " = ", num0 * num1, "\n"
print num0, " / ", num1, " = ", num0 / num1, "\n"
