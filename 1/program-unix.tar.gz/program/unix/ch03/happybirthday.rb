name = ARGV[0]
print "Happy Birthday, ", name, "!\n"
