def hello(name="Ruby")
  print("Hello, ", name, ".\n")
end
hello()            # $B0z?t$r>JN,$7$F8F$S=P$9(B
hello("Newbie")    # $B0z?t$r;XDj$7$F8F$S=P$9(B
