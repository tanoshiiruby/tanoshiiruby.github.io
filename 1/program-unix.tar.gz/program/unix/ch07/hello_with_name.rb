def hello(name)
  print("Hello, ", name, ".\n")
end
hello("Ruby")
