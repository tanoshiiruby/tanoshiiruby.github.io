def du(path)
  st = File.stat(path)
  result = st.size
  if st.directory?
    Dir.open(path){|dir|
      dir.each{|name|
        next if name == "." || name == ".."
        result += du(File.join(path, name))
      }
    }
  end
  printf("%8d %s\n", result, path)
  result
end
