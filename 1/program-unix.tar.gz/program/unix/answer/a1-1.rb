def fahr2celsius(fahr)
  5.0 * (fahr-32) / 9
end
