require 'rbconfig'

def printLibrary
  dlext = Config::CONFIG["DLEXT"]
  $:.each{|path|
    next unless FileTest.directory?(path)
    Dir.open(path){|dir|
      dir.each{|name|
        if name =~ /\.(rb|#{dlext})$/
          puts name
        end
      }
    }
  }
end

