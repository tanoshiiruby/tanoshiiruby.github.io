def word_capitalize(str)
  return str.split(/\-/).collect{|w| w.capitalize}.join('-')
end

if __FILE__ == $0
  p word_capitalize("in-reply-to") #=> "In-Reply-To"
  p word_capitalize("X-MAILER")    #=> "X-Mailer"
end
