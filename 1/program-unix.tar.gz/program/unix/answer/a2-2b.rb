def sum_array(nums1, nums2)
  tmp_nums2 = nums2.dup
  return nums1.collect{|num|
    num + tmp_nums2.shift
  }
end

if __FILE__ == $0
  p sum_array([1,2,3], [4,6,8])
end

