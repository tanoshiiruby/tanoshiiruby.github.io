def square(nums)
  return nums.collect{|num|
    num * num
  }
end
