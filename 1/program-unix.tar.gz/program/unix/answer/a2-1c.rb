def square(nums)
  ret = Array.new()
  i = 0
  while i < nums.length
    ret[i] = nums[i] * nums[i]
    i += 1
  end
  ret
end
