class Celsius
  def initialize(celsius)
    @celsius = celsius
  end

  def to_celsius
    @celsius
  end

  def to_fahr
    (@celsius*9.0/5)+32
  end

  def +(other)
    @celsius += other
    self
  end

  def -(other)
    @celsius -= other
    self
  end

end

if __FILE__ == $0
  c1 = Celsius.new(30)
  c2 = c1 + 10
  p c2
  p c2.to_celsius
  p c2.to_fahr

  c2 = c1 - 10
  p c2
  p c2.to_celsius
  p c2.to_fahr
  
end
