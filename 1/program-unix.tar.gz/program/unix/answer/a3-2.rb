def num2astrisk(str)
  num = ""
  str.split(//).each{|char|
    num = num + num + num + num + num +
      num + num + num + num + num
    char.sub!("0","")
    char.sub!("1","*")
    char.sub!("2","**")
    char.sub!("3","***")
    char.sub!("4","****")
    char.sub!("5","*****")
    char.sub!("6","******")
    char.sub!("7","*******")
    char.sub!("8","********")
    char.sub!("9","*********")
    num = num + char
  }

  num
end

if __FILE__ == $0
  num = ARGV[0]
  str = num2astrisk(num)
  print "astrisk: '#{str}'\n"
  print "length:  #{str.length}\n"
end
