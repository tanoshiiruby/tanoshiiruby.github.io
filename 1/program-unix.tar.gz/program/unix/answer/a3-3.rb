class StringIO

  def initialize(str="")
    @str = str
    @pos = 0
  end


  def read(n)
    if n < 0
      raise ArgumentError, "negative length #{n} given"
    end
    
    ret = @str[@pos, n]
    @pos += n
    if @pos > @str.length
      @pos = @str.length
    end

    ret
  end

    
  def gets(sep="\n")
    if @pos >= @str.length
      return nil
    end

    pos = @str.index(sep, @pos)
    if pos.nil?
      pos = @str.length
    end
    ret = @str[@pos..pos]
    @pos = pos + 1

    return ret 
  end


  def rewind()
    @pos = 0
  end

end

if __FILE__ == $0
  sio = StringIO.new("̩��\n��\n�֤ȹ�\n�\n��")
  p sio.gets #=> "̩��\n"
  p sio.gets #=> "��\n"
  p sio.gets #=> "�֤ȹ�\n"
  p sio.gets #=> "�\n"
  p sio.gets #=> "��"
  p sio.gets #=> nil
  p sio.gets #=> nil
  sio.rewind
  p sio.gets #=> "̩��\n"
  
  sio.rewind
  p sio.read(5) #=> "̩��\n"
  p sio.read(3) #=> "��\n"
  p sio.read(7) #=> "�֤ȹ�\n"
  p sio.read(3) #=> "�\n"
  p sio.read(3) #=> "��"
  p sio.read(2) #=> nil
  p sio.read(2) #=> nil
end
