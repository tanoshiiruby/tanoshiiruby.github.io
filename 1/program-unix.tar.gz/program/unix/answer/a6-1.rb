def copy(file1, file2)
  open(file1){|io1|
    open(file2, "w"){|io2|
      while data = io1.read(1024*64)
        io2.write(data)
      end
    }
  }
end

