require 'rational'

a = Rational(1,10) + Rational(2,10)
p a #=> Rational(3,10)
b = (a == Rational(3,10))
p b #=> true
