def divisible(x,y)
  (1..x).each{|z|
    if x == y * z
      return true
    end
  }
  return false
end

def prim(x)
  (1..x).each{|z|
    if (z != 1 && z != x && divisible(x,z) && x > 1)
      return false
    end
  }
  return true
end

