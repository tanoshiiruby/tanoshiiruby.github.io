def copydir(dir1, dir2)
  raise "Error: #{dir2} exists." if FileTest.exist?(dir2)
  Dir.open(dir1){|dir| 
    Dir.mkdir(dir2)
    dir.each{|name|
      next if name == "." || name == ".."
      path1 = File.join(dir1, name)  
      path2 = File.join(dir2, name)
      st = File.lstat(path1)         # lstat ��Ȥ�
      if st.file?
        copy(path1, path2)
      elsif st.directory?
        copydir(path1, path2)
      elsif st.symlink?
        File.symlimk(File.readlink(path1), path2)
      else
        $stderr.puts "unknow file type: #{path1}"
      end
    }
  }
end
