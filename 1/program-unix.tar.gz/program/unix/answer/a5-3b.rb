def word_capitalize(str)
  ret = ""
  str.scan(/(\w+)(\W*)/){|word, no_word|
    ret << word.capitalize + no_word
  }
  return ret
end

if __FILE__ == $0
  p word_capitalize("in-reply-to") #=> "In-Reply-To"
  p word_capitalize("X-MAILER")    #=> "X-Mailer"
end
