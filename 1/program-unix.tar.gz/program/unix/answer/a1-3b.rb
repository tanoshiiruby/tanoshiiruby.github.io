require 'mathn'
include Math

def prime?(num)
  p sqrt(num)
  (2..sqrt(num)).each{|i|
    if num % i == 0
      return false
    end
  }
  return true
end

