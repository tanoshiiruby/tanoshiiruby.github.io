def sum_array(nums1, nums2)
  ret = Array.new()
  nums1.each_with_index{|num, i|
    ret << num + nums2[i]
  }
  ret
end
