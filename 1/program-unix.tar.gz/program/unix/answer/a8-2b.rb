def ls_t(path)
  Dir.open(path){|dir|
    hash = {}
    ary = dir.sort{|ent1, ent2|
      unless hash[ent1]
        hash[ent1] = File.mtime(File.join(path, ent1))
      end
      unless hash[ent2]
        hash[ent2] = File.mtime(File.join(path, ent2))
      end
      hash[ent1] <=> hash[ent2]
    }
  }
end
