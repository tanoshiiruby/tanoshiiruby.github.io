def square(nums)
  ret = Array.new()
  nums.each{|num|
    ret << num * num
  }
  ret
end
