def get_local_and_domain(str)
  str =~ /^[^@]+@.*$/
  localpart = $1
  domain = $2
  return localpart, domain
end
