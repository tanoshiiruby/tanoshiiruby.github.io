def printLibrary
  $:.each{|path|
    next unless FileTest.directory?(path)
    Dir.open(path){|dir|
      dir.each{|name|
        if name =~ /\.rb$/
          puts name
        end
      }
    }
  }
end

