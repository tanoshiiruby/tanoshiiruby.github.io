def str2hash(str)
  hash = Hash.new()
  array = str.split(/\s+/)
  while key = array.shift
    value = array.shift
    hash[key] = value
  end
  hash
end

if __FILE__ == $0
    p str2hash("bule ��  white ��\nred  ��");
      #=> {"blue"=>"��", "white"=>"��", "red"=>"��"}
  
end
