def prime?(num)
  (2...num).each{|i|
    if num % i == 0
      return false
    end
  }
  return true
end

