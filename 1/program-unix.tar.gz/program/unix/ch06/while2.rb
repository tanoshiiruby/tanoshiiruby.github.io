sum = 0
i = 1
while i <= 5
  sum += i
  i += 1
end
print sum,"\n"
