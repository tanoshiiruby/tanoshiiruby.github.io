sum = 0
(1..5).each{|i|
  sum = sum + i
}
print sum,"\n"
