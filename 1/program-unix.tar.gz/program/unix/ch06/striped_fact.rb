ans = 1
for i in 1..10
  ans *= i
end
print "10! = ", ans, "\n"
