i = 1
while i<3
  print i,"\n"
  i+=1
end
