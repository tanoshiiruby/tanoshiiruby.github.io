sum = 0
for i in 1..5
  sum = sum + i
end
print sum,"\n"
