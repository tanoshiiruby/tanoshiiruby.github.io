sum = 0
i = 1
while sum<50
  sum += i
  i += 1
end
print sum,"\n"
