names = ["awk","Perl","Python","Ruby"]
for name in names
  print name,"\n"
end
