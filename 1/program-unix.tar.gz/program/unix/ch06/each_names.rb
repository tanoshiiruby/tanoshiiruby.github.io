names = ["awk","Perl","Python","Ruby"]
names.each{|name|
  print name,"\n"
}
