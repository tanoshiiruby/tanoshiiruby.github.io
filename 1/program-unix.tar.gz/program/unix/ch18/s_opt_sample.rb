puts "$foo: #{$foo}"
puts "$bar: #{$bar}"
puts "$baz: #{$baz}"
