class WarningTest
  def initialize
    @test = "test."
  end
  def test
    print @tset,"\n"     ##��@test�פ��@tset�פȽ񤤤Ƥ���!
  end
end

sample_test = WarningTest.new
sample_test.test
