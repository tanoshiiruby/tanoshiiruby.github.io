"abracatabra".scan(/(.)(a)/){|matched|
  p matched
}
