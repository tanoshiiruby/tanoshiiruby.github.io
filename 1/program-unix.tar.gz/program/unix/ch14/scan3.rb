"abracatabra".scan(/(.)(a)/){|a, b|
  p a+"-"+b
}
