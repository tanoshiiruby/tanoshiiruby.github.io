list = [1, 3, 5, 7, 9]
sum = 0
list.each{|elem|
  sum += elem
}
print "���:",sum,"\n"
