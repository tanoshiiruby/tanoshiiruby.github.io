list = [1, 3, 5, 7, 9]
sum = 0
for i in 0...list.length
  sum += list[i]
end
print "���:",sum,"\n"
